import styled from "@emotion/styled";
import React, { useState } from "react";
import Accordion from "react-bootstrap/Accordion";
import cn from "classnames";

import EButton from "../EButton";
import { TAccordionItem } from "../../pages/Home";
import { ReactComponent as AccordionCaret } from "../../assets/images/accordion-caret.svg";

interface HomeAccodionProps {
  accordionItems: TAccordionItem[];
}

const StyledHomeAccordion = styled.div`
  padding-bottom: 30px;

  @media screen and (min-width: 768px) {
    padding-bottom: 190px;
  }

  h3.section-header {
    font-size: 22px;
    line-height: 26px;
    text-align: center;
    padding-bottom: 22px;
    margin-bottom: 20px;
    position: relative;

    &::after {
      content: "";
      position: absolute;
      bottom: 0;
      width: 45%;
      height: 4px;
      left: 50%;
      transform: translateX(-50%);
      border-radius: 4px;
      background-color: ${(props) => props.theme.border.primary};
    }

    @media screen and (min-width: 768px) {
      font-size: 30px;
      line-height: 36px;
      margin-bottom: 70px;

      &::after {
        width: 125%;
      }
    }
  }
  h5.accordion-item-header {
    font-size: 18px;
    line-height: 22px;
  }

  .accordion-item {
    border: none;
    background-color: transparent;
  }

  .accordion-button {
    color: ${(props) => props.theme.color.disabled};
    font-size: 16px;
    line-height: 22px;
    font-weight: 400;
    background: transparent;
    box-shadow: none;
    display: flex;
    align-items: center;
    padding-right: 2rem;

    &::after {
      display: none;
    }

    .caret-icon-container {
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      .svg-fill {
        fill: ${(props) => props.theme.color.primary} !important;
      }
    }

    .svg-stroke {
      stroke: ${(props) => props.theme.color.disabled};
    }
    .svg-fill {
      fill: ${(props) => props.theme.color.disabled};
    }

    &:not(.collapsed) {
      background: ${(props) => props.theme.background.transparent};
      color: ${(props) => props.theme.color.primary};

      .svg-stroke {
        stroke: ${(props) => props.theme.color.primary};
      }
      .svg-fill {
        fill: ${(props) => props.theme.color.primary};
      }
    }
  }

  .accordion-body {
    background: rgba(0, 0, 0, 0.03);
  }

  .desktop-accordion-container {
    .accordion-item {
      border: none;
    }

    .accordion-item-header {
      .accordion-button {
        background: transparent;
        border: none;
        border-radius: 4px;
        transition: all 0.3s ease-in-out;
      }

      &.active {
        .accordion-button {
          background: ${(props) => props.theme.background.transparent};
          color: ${(props) => props.theme.color.primary};

          .svg-stroke {
            stroke: ${(props) => props.theme.color.primary};
          }
          .svg-fill {
            fill: ${(props) => props.theme.color.primary};
          }
        }
      }
    }

    .accordion-body {
      background-color: transparent;
    }

    .caret-icon-container {
      right: 15px;
      top: 50%;
      transform: translateY(-50%) rotate(-90deg);
      .svg-fill {
        fill: ${(props) => props.theme.color.primary} !important;
      }
    }
  }
`;

const HomeAccodion: React.FC<HomeAccodionProps> = ({ accordionItems }) => {
  const [activeItemIndex, setActiveItemIndex] = useState(0);

  return (
    <StyledHomeAccordion className="d-flex flex-column justify-content-center align-items-center">
      <h3 className="section-header fw-bold">Synthetic Asset Ecosystem</h3>

      <div className="mobile-accordion-container d-lg-none w-100">
        <Accordion defaultActiveKey="0">
          {accordionItems.map((accordionItem, index) => (
            <Accordion.Item eventKey={`${index}`} key={index}>
              <Accordion.Header className="accordion-item-header">
                <accordionItem.Icon
                  className={cn("me-3", accordionItem.iconClassName || "")}
                />
                <span className="button-text">{accordionItem.headerText}</span>

                <span className="caret-icon-container position-absolute">
                  <AccordionCaret />
                </span>
              </Accordion.Header>
              <Accordion.Body>
                <h5 className="fw-bold">{accordionItem.headerText}</h5>
                <p>{accordionItem.body}</p>
                {accordionItem.buttonText && (
                  <EButton className="d-block mx-auto" type="primary">
                    {accordionItem.buttonText}
                  </EButton>
                )}
              </Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>
      </div>

      {/* Desktop Accordion */}
      <div className="container desktop-accordion-container d-none d-lg-block w-100">
        <div className="row">
          <div className="col-6">
            {accordionItems.map((accordionItem, index) => (
              <Accordion.Item
                eventKey=""
                key={index}
                onClick={() => setActiveItemIndex(index)}
              >
                <Accordion.Header
                  className={cn("accordion-item-header", {
                    active: index === activeItemIndex,
                  })}
                >
                  <accordionItem.Icon
                    className={cn("me-3", accordionItem.iconClassName || "")}
                  />
                  <span className="button-text">
                    {accordionItem.headerText}
                  </span>

                  <span className="caret-icon-container position-absolute">
                    <AccordionCaret />
                  </span>
                </Accordion.Header>
              </Accordion.Item>
            ))}
          </div>
          <div className="col-6">
            <div className="accordion-body">
              <h5 className="fw-bold">
                {accordionItems[activeItemIndex].headerText}
              </h5>
              <p>{accordionItems[activeItemIndex].body}</p>
              {accordionItems[activeItemIndex].buttonText && (
                <EButton className="d-block mx-auto" type="primary">
                  {accordionItems[activeItemIndex].buttonText}
                </EButton>
              )}
            </div>
          </div>
        </div>
      </div>
    </StyledHomeAccordion>
  );
};

export default HomeAccodion;
