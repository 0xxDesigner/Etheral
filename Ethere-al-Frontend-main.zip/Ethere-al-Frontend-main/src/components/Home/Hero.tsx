import styled from "@emotion/styled";
import React from "react";
import EButton from "../EButton";

const StyledHero = styled.header`
  padding-top: 35px;
  padding-bottom: 100px;

  @media screen and (min-width: 786px) {
    padding-top: 130px;
    padding-bottom: 160px;

    .title {
      line-height: 50px;
    }
  }

  .docs-link {
    font-size: 18px;
    line-height: 22px;
    color: ${(props) => props.theme.color.primary};
    text-decoration: underline;
  }
`;

const Hero: React.FC = () => {
  return (
    <StyledHero className="container d-flex flex-column align-items-center">
      <h2 className="text-center title mb-5">
        <span className="fw-bold">ethere.al</span> | bridge the gap between
        traditional finance and crypto using our cross-chain platform for
        minting synthetic hedges for world volatility events with an
        over-collateralized fusion Treasury system
      </h2>

      <EButton type="primary" onClick={() => window.location.href = 'http://app.ethere.al/'}>Launch App</EButton>

      <a className="docs-link fw-bold mt-4" href="/#">
        Read Docs
      </a>
    </StyledHero>
  );
};

export default Hero;
