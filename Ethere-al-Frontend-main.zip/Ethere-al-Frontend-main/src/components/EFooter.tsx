import styled from "@emotion/styled";
import React from "react";
import { useNavigate } from "react-router";
// import Container from "react-bootstrap/Container";
import EButton from "./EButton";

interface EFooterProps {
  showContent?: boolean;
}

const EFooter: React.FC<EFooterProps> = ({ showContent = false }) => {
  const navigate = useNavigate();
  return (
    <StyledEFooter>
      <div className="container d-flex flex-column align-items-center">
        {showContent && (
          <>
            <h4 className="text-center footer-title">
              Partnered with Wault Finance and Audited by Certik
            </h4>
            <EButton
              type="secondary"
              onClick={() => {
                navigate("/roadmap");
              }}
            >
              Roadmap
            </EButton>
          </>
        )}
      </div>
    </StyledEFooter>
  );
};

export default EFooter;

const StyledEFooter = styled.footer`
  background: ${(props) => props.theme.background.secondary};
  color: ${(props) => props.theme.color.secondary};
  padding: 30px 0 35px;
  min-height: 90px;

  .footer-title {
    font-size: 22px;
    font-weight: 400;
    line-height: 26px;
    margin-bottom: 40px;
  }
  @media screen and (min-width: 768px) {
    padding: 35px 0 40px;

    .footer-title {
      font-size: 30px;
      line-height: 36px;
      margin-bottom: 22px;
    }
  }
`;
