import { createAction } from "@reduxjs/toolkit";

export const toggleSidebar = createAction("toggleSidebar");
export const toggleTheme = createAction("toggleTheme");
