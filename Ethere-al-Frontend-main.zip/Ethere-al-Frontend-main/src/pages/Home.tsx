import styled from "@emotion/styled";
import React from "react";
import EFooter from "../components/EFooter";
import Hero from "../components/Home/Hero";
import BackgroundContainer from "../components/BackgroundContainer";
import Navbar from "../components/Shared/Navbar";

import { ReactComponent as AccordionIcon1 } from "../assets/images/accordion-icons/item1.svg";
import { ReactComponent as AccordionIcon2 } from "../assets/images/accordion-icons/item2.svg";
import { ReactComponent as AccordionIcon3 } from "../assets/images/accordion-icons/item3.svg";
import { ReactComponent as AccordionIcon4 } from "../assets/images/accordion-icons/item4.svg";
import { ReactComponent as AccordionIcon5 } from "../assets/images/accordion-icons/item5.svg";
import HomeAccodion from "../components/Home/HomeAccodion";

const StyledHome = styled.section``;

export type TAccordionItem = {
  Icon: React.FunctionComponent<
    React.SVGProps<SVGSVGElement> & {
      title?: string | undefined;
    }
  >;
  headerText: string;
  body: string;
  buttonText: string;
  iconClassName?: string;
};

const accordionItems: TAccordionItem[] = [
  {
    Icon: AccordionIcon1,
    iconClassName: 'ms-1',
    headerText: "ISA | Interchangeable Synthetic Asset",
    body: `The platform’s inflationary token, ISA, is used to mint all synthetic hedges within the protocol.
    During the mintage of any synthetic asset, ISA is 100% locked in the Treasury to generate
    additional yields at a rate congruent with the asset’s price at the time of the mint. It has a hard
    cap of 120m with an initial supply of 25m. Emissions stand at 5 ISA per block, equating to a 1.8-
    year timeline before reaching the max supply. See the expanded breakdown further on for a
    complete analysis of its economics.`,
    buttonText: "Trade ISA",
  },
  {
    Icon: AccordionIcon2,
    headerText: "eTY | 3x, 5x, 10x Leveraged US Ten Year Yield Hedge",
    body: `With the divergence of opinion on whether BTC is positively correlated to inflation, we have
    developed a synthetic asset that tracks the US Ten Year Treasury Rate (the “Rate”) at a leveraged
    rate between 3-10x. The asset is minted using ISA under the mint section, of which 100% is
    locked in the Treasury to generate additional yields. The resulting asset price will move
    following the Rate. A fee of 0.5% applies at the time of mint, which routes to the Treasury. See
    our Treasury section to read more about its strengths and long-term objectives.`,
    buttonText: "Mint eTY",
  },
  {
    Icon: AccordionIcon3,
    headerText: "eITY | Inverse 3x, 5x, 10x Leveraged US Ten Year Yield Hedge",
    body: `Like eTY, eITY allows you to mint inverse leveraged assets that inversely track the Rate. The
    same mintage, swap, and burn dynamics apply to eITY. However, when paired with eTY, one can
    minimize short-term risk as the assets move tick per tick against one another. While this exposes
    the position to impermanent loss, depending on the leverage used while minting, this is usually
    quickly offset by ISA bond rewards when sold to the Treasury. Furthermore, the mintage of both
    allows additional short-term flexibility for your hedging objectives. The same safety measures
    utilized for stabilizing eTY against a black swan event are present for eITY.`,
    buttonText: "Mint eITY",
  },
  {
    Icon: AccordionIcon4,
    headerText: "eBTC - eETH | Inverse Large Cap Assets",
    body: `Using similar mint mechanics as eTY and eITY, one can mint two separate large-cap inverse
    hedges using ISA. Rather than opening a leveraged farm to short either BTC or ETH, you can
    create a synthetic asset that inversely follows the price action of the underlying token with a click
    of a button. As such, you can collect a higher yield rate over time upon selling them to the
    Treasury, decreasing your overall risk of holding either the inverse or underlying asset. We will
    add additional large-cap tokens in the future once our platform achieves a more robust Treasury.
    The community can also decide these additions through future governance.`,
    buttonText: "Mint eBTC | eETH",
  },
  {
    Icon: AccordionIcon5,
    headerText: "Non-Traditional Hedges",
    body: `Coming tentatively in the first half of 2022, we will introduce the ability to mint specific hedges
    against real-world volatility events that are difficult to hedge using traditional financial assets
    such as volatility-killing option spreads. These community-driven asset classes will be minted
    using ISA and carry their own risks and rewards to diversify your portfolio hedges further. We
    will release more information as logistics are finalized and feasibility tests are completed in
    January of 2022. Follow our announcement telegram channel to stay up to date with the latest
    developments platform-wide.`,
    buttonText: "Coming Soon",
  },

];

const Home: React.FC = () => {
  return (
    <StyledHome>
      <BackgroundContainer backgroundPosition="top">
        <Navbar />
        <Hero />
        <HomeAccodion accordionItems={accordionItems} />
      </BackgroundContainer>
      <EFooter showContent />
    </StyledHome>
  );
};

export default Home;
